package com.dailycodebuffer.ServiceB.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/b")
public class ServiceBController {

    @GetMapping
    public String serviceB(HttpServletResponse response) {
        response.addHeader("Baeldung-Example-Header", "Value-HttpServletResponse");
        response.addHeader("x-rate-limit-remaining", "3");
        response.addHeader("x-rate-retry-sec", "30");
//        response.cod
        return "Service B is called from Service A";
    }

}
