package com.dailycodebuffer.ServiceA.service;

import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Date;

@Service
public class ServiceA {
    @Autowired
    private RestTemplate restTemplate;
    int count = 1;
    @Retry(name = "serviceA"/*, fallbackMethod = "serviceA"*/)
    public String getResponse(){

        System.out.println("Retry method called " + count++ + " times at " + new Date());
        RestTemplate template = new RestTemplate();
        HttpEntity<String> response = template.exchange( "http://localhost:8081/b", HttpMethod.GET,null, String.class);
//        restTemplate.getForObject(
//                "http://localhost:8081/b",
//                String.class
//        );
        String resultString = response.getBody();
        HttpHeaders headers = response.getHeaders();
        System.out.println(resultString);
        System.out.println(headers);
        return  response.getBody();
    }

    public ResponseEntity<String> initialCall( Integer sec){

        RestTemplate template = new RestTemplate();
        ResponseEntity<String> response = template.exchange( "http://localhost:8081/b", HttpMethod.GET,null, String.class);
//        restTemplate.getForObject(
//                "http://localhost:8081/b",
//                String.class
//        );
//        String resultString = response.getBody();
//        HttpHeaders headers = response.getHeaders();
//        System.out.println(resultString);
//        System.out.println(headers);

        if(sec == 10000){
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
        }
        return  response;
    }
}
