package com.dailycodebuffer.ServiceA.controller;

import com.dailycodebuffer.ServiceA.service.ServiceA;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

@RestController
@RequestMapping("/a")
public class ServiceAController {

    private static final String BASE_URL
            = "http://localhost:8081/";

    //    @Autowired
//    private RestTemplate restTemplate;
    private static final String SERVICE_A = "serviceA";
    @Autowired
    ServiceA serviceA;
    int count = 1;
    @Autowired
    private RetryRegistry retryRegistry;

    private Retry configRetry(int sec) {
        RetryConfig retryConfig = RetryConfig.custom().maxAttempts(3)
                .waitDuration(Duration.ofMillis(sec)).build();
        Retry retry = Retry.of(SERVICE_A, retryConfig);
        return retry;
    }

    @GetMapping("{sec}")
    //@CircuitBreaker(name = SERVICE_A, fallbackMethod = "serviceAFallback")
//    @Retry(name = SERVICE_A)
//    @RateLimiter(name = SERVICE_A)

    public String serviceA(@PathVariable Integer sec) {
//        RetryRegistry retryRegistry = null;
        String resp = "";
        try {
            ResponseEntity<String> response = serviceA.initialCall(sec);
            HttpHeaders headers = response.getHeaders();
            int a = Integer.parseInt(headers.get("x-rate-retry-sec").get(0));
            resp = response.getBody();
            if (response.getStatusCode().value() > 299) {
                System.out.println("Status Code" + 299);
                retryRegistry.retry("serviceA", RetryConfig.custom().maxAttempts(9)
                        .waitDuration(Duration.ofMillis(a))
                        .build());
                resp = serviceA.getResponse();
            }
            //            if()
        } catch (Exception e) {
            System.out.println("Error");
            retryRegistry.retry("serviceA", RetryConfig.custom().maxAttempts(9)
                    .waitDuration(Duration.ofMillis(sec))
                    .build());
            resp = serviceA.getResponse();


        }
//        retryRegistry.retry("serviceA", RetryConfig.custom().maxAttempts(9)
//                .waitDuration(Duration.ofMillis(sec))
////                .retryExceptions(CustomException.class)
////                .failAfterMaxAttempts(true)
//                .build());

        String url = BASE_URL + "b";
//        System.out.println("Retry method called " + count++ + " times at " + new Date());
        Retry r = configRetry(sec);
//        Callable<String> c = restTemplate.getForObject(
//                url,
//                String.class
//        );
//        Retry.decorateCallable(r, )
//        return serviceA.getResponse();
        return resp;
    }

    public String serviceAFallback(Exception e) {
        return "This is a fallback method for Service A";
    }

    //    @Configuration
//    @EnableAsync
    @GetMapping("async")
    @Async
    Future<String> returnSomething() {
// this will be executed asynchronously
        return CompletableFuture.supplyAsync(() -> "Tessssssssss");
    }

}
